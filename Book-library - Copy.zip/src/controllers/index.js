/* eslint-disable import/no-unresolved */
const addBook = require('./addBook');
const getbook = require('./getbook');

module.exports = {
  addBook, getbook,
};
